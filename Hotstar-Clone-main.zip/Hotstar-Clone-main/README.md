# Hotstar-Clone
This is the project of the bootcamp on HTML, CSS and Bootstrap conducted by DevTown .

[Visit Website](https://jd82me.csb.app/)

![hotstar](https://user-images.githubusercontent.com/70633140/183292743-2ae13e7c-31e7-45ee-af58-485355a1ea9e.png)
